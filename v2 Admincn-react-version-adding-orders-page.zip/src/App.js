import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";

import { ThemeProvider } from "./components/ThemeProvider";
import AppLayout from "./layouts/AppLayout";
import Dashboard from "./pages/Dashboard";
import OrdersDashboard from "./pages/OrdersDashboard";

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route
              path="/"
              element={<Navigate to="/dashboard/orders" replace />}
            />

            <Route
              path="/dashboard"
              element={<Dashboard />}
            />

            <Route
              path="/dashboard/orders"
              element={<OrdersDashboard />}
            />

            <Route
              path="*"
              element={<Navigate to="/dashboard/orders" replace />}
            />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
