import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";

import { ThemeProvider } from "./components/ThemeProvider";
import AppLayout from "./layouts/AppLayout";

import Dashboard from "./pages/Dashboard";
import OrdersDashboard from "./pages/OrdersDashboard";

import MailApp from "./views/apps/mail";
import { EventCalendar } from "./views/apps/calendar";
import UserListApp from "./views/apps/users/list";
import UserViewApp from "./views/apps/users/view";
import UserSetting from "./views/pages/user-settings";
import UserProfile from "./views/pages/user-profile";

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route
              path="/"
              element={<Navigate to="/dashboard/orders" replace />}
            />

            {/* Dashboard */}
            <Route
              path="/dashboard"
              element={<Dashboard />}
            />
            <Route
              path="/dashboard/orders"
              element={<OrdersDashboard />}
            />

            {/* Mail */}
            <Route 
              path="/apps/mail" 
              element={<MailApp />} 
            />

            {/* Calendar */}
            <Route 
              path="/apps/calendar" 
              element={<EventCalendar />} 
            />

            {/* Users */}
            <Route
              path="/apps/users/list"
              element={<UserListApp />}
            />
            <Route
              path="/apps/users/view"
              element={<UserViewApp />}
            />

            {/* User pages */}
            <Route
              path="/pages/user-profile"
              element={<UserProfile />}
            />
            <Route
              path="/pages/user-settings"
              element={<UserSetting />}
            />

            {/* Unknown routes */}
            <Route
              path="*"
              element={<Navigate to="/dashboard/orders" replace />}
            />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}